//
//  ViewController.swift
//  ProyectInterfaz
//
//  Created by usuario on 9/5/20.
//  Copyright © 2020 Eduardo Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

